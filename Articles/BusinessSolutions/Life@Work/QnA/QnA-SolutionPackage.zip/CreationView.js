// Globals
var form; // type: KASForm
var currentUserID;
var attachments = null;
var strings = {};

function onPageLoad() {
    // Register for Android h/w back press event
    KASClient.App.registerHardwareBackPressCallback(function() {
        KASClient.App.dismissCurrentScreen();
    });
    // Get strings from strings.json file for localization purpose
    KASClient.App.getLocalizedStringsAsync(function(localizedStrings, error) {
        if (error != null) {
            //Non recoverable error
            KASClient.App.dismissCurrentScreen();
            return;
        }
        strings = localizedStrings;
        // Get the default form
        KASClient.Form.getFormAsync(function(formDetails, error) {
            if (error != null) {
                showErrorMessage();
                return;
            }
            // Fetch conversation details from which we can get current user ID.
            KASClient.App.getConversationDetailsAsync(function(conversationDetails, error) {
                if (error != null) {
                    showErrorMessage();
                    return;
                }
                // Gets users' details (name, pic, phone number, etc.) against their ids
                KASClient.App.getUsersDetailsAsync([conversationDetails.currentUserId], function(users, error) {
                    if (error != null) {
                        showErrorMessage();
                        return;
                    }
                    form = formDetails;
                    currentUserID = users[conversationDetails.currentUserId];
                    setInitialText();
                    initializeEventListeners();
                    createInputDiv();
                });
            });
        });
    });
}

function keyUpHandler(event) {
    var submitButton = document.getElementById("submit-ques");
    if (document.getElementById("input-question-text").innerText != "") {
        submitButton.disabled = false;
    } else {
        submitButton.disabled = true;
    }
}

function submitFormRequest() {
    var properties = [];
    properties.push(createPropertyWithValue("question", KASClient.KASFormPropertyType.Text,
        document.getElementById("input-question-text").innerText));
    if (attachments) {
        properties.push(createPropertyWithValue("coverImage",
            KASClient.KASFormPropertyType.Attachment, attachments));
    }
    var time = new Date().toLocaleTimeString([] /* it takes default locale of device */ , { hour: "2-digit", minute: "2-digit" }) + ", " +
        new Date().toLocaleDateString([], { day: "numeric", month: "short" });
    properties.push(createPropertyWithValue("time", KASClient.KASFormPropertyType.Text, time));

    // In chat canvas view, when there is no comment added below string is shown
    properties.push(createPropertyWithValue("lastResponder", KASClient.KASFormPropertyType.Text, strings["noAnswer"]));
    properties.push(createPropertyWithValue("askedByUserId", KASClient.KASFormPropertyType.Text, currentUserID.id));
    form.properties = properties;
    form.visibility = KASClient.KASFormResultVisibility.MembersAndSubscribers;
    KASClient.Form.submitFormRequest(form);
}
/*
addAttachment(): Allows user to add attachment from device
*/
function addAttachment() {
    KASClient.App.showImagePickerAsync(function(selectedImagePath, error) {
        if (error != null) {
            showErrorMessage();
        }
        if (selectedImagePath) {
            displayImageThumbnail(selectedImagePath);
            attachments = selectedImagePath;

        }
    });
}

function createInputDiv() {
    var inputDiv = document.getElementById("input-question-div");
    var textInput = document.createElement("span");
    textInput.id = "input-question-text";
    textInput.className = "input-question-text";
    textInput.contentEditable = true;
    textInput.setAttribute("placeholder", strings["inputQuesPlaceholder"]);
    textInput.addEventListener("keyup", keyUpHandler);
    inputDiv.appendChild(textInput);
}
/*
displayImageThumbnail(attachment): Show the attachment as thumbnails
*/
function displayImageThumbnail(attachment) {
    document.getElementById("section-selected-img").src = attachment;
    document.getElementById("img-div").style.display = "block";
    document.getElementById("attachment-div").style.display = "none";
}
/*
removeAttachment(): Remove an attachment
*/
function removeAttachment() {
    attachments = null;
    document.getElementById("section-selected-img").src = "";
    document.getElementById("attachment-div").style.display = "block";
    document.getElementById("img-div").style.display = "none";
}

/*
setInitialText(): Initialized placeholders and button texts
*/
function setInitialText() {
    document.getElementById("header-label").innerText = strings["displayName"];
    document.getElementById("submit-ques").innerText = strings["submitButton"];
    document.getElementById("error-message-title").textContent = strings["errorMessageTitle"];
    document.getElementById("error-message-subtitle").textContent = strings["errorMessageSubtitle"];
    document.getElementById('ok-button-text').textContent = strings['Ok'];
}
/*
initializeEventListeners(): Initialize the event listeners in the page
*/
function initializeEventListeners() {
    document.getElementById("attachment-img").addEventListener("click", addAttachment);
    document.getElementById("submit-ques").addEventListener("click", submitFormRequest);
    document.getElementById("cancel-img").addEventListener("click", removeAttachment);
    document.getElementById("back-button").addEventListener("click", KASClient.App.dismissCurrentScreen);
    document.getElementById('ok-button-text').addEventListener('click', KASClient.App.dismissCurrentScreen);
}

//Create property
function createPropertyWithValue(name, type, value) {
    var property = new KASClient.KASFormProperty();
    property.name = name;
    property.type = type;
    property.value = value;
    return property;
}

function showErrorMessage() {
    document.getElementById("error-message-outer-div").style.display = "flex";
}