// Globals
var currentUserInfo;
var strings = {};

function onPageLoad() {
    // Register for Android h/w back press event
    KASClient.App.registerHardwareBackPressCallback(function() {
        KASClient.App.dismissCurrentScreen();
    });
    KASClient.App.getLocalizedStringsAsync(function(localizedStrings, error) {
        if (error != null) {
            //Non recoverable error
            KASClient.App.dismissCurrentScreen();
            return;
        }
        strings = localizedStrings;
        // Get the default form
        // Fetch conversation details from which we can get current user ID.
        KASClient.App.getConversationDetailsAsync(function(conversationDetails, error) {
            if (error != null) {
                showErrorMessage(strings["errorMessageSubtitle"]);
                return;
            }
            // Gets users' details (name, pic, phone number, etc.) against their ids
            KASClient.App.getUsersDetailsAsync([conversationDetails.currentUserId], function(users, error) {
                if (error != null) {
                    showErrorMessage(strings["errorMessageSubtitle"]);
                    return;
                } // Get strings from strings.json file for localization purpose
                currentUserInfo = users[conversationDetails.currentUserId];
                setInitialText();
                initializeEventListeners();
                loadQuestionData();
                checkOnline();
                createInputDiv();
                fetchAndShowAllResponses();
            });
        });
    });
}

function createInputDiv() {
    var inputDiv = document.getElementById("input-answer-div");
    var textInput = document.createElement("span");
    textInput.id = "input-answer";
    textInput.className = "input-answer";
    textInput.contentEditable = true;
    textInput.setAttribute("placeholder", strings["inputAnswerPlaceholder"]);
    inputDiv.appendChild(textInput);
}

function fetchAndShowAllResponses() {
    KASClient.Form.getFormSummaryAsync(
        // Data fetched from database
        function(flatSummaryDetails, processedSummaryDetails, error) {
            if (error != null) {
                showErrorMessage(strings["errorMessageSubtitle"]);
                return;
            }
        },
        // Data fetched from server
        function(flatSummaryDetails, processedSummaryDetails, error) {
            if (error != null) {
                showErrorMessage(strings["errorMessageSubtitle"]);
                return;
            }
            var flatSummary = flatSummaryDetails;
            var allResponses = flatSummary.getAllResponses();
            showAllResponses(flatSummary, allResponses);
        }
    );

}
/*
setInitialText(): Initialized placeholders and button texts
*/
function setInitialText() {
    document.getElementById("header-label").innerText = strings["displayName"];
    document.getElementById("refresh-label").innerText = strings["refresh"];
    document.getElementById("askedBy-label").innerText = strings["askedBy"];
    document.getElementById("answer-header").innerText = strings["answerHeader"];
    document.getElementById("no-answer-text").innerText = strings["noAnswer"];
}
/*
initializeEventListeners(): Initialize the event listeners in the page
*/
function initializeEventListeners() {
    document.getElementById('send-answer').addEventListener('click', submitResponse);
    document.getElementById('refresh-label').addEventListener('click', reload);
    document.getElementById("back-button").addEventListener("click", KASClient.App.dismissCurrentScreen);
}

function showAllResponses(flatSummary, allResponses) {
    var allAnswers = [];
    for (var userId in allResponses) {
        var userResponses = allResponses[userId]; // type: Array<QuestionId: Answer>
        for (var i = 0; i < userResponses.length; i++) {
            var answer = { userId: userId, userResponse: userResponses[i] }
            allAnswers.push(answer);
        }
    }
    var respondedUserIds = flatSummary.getRespondedUserIds();
    if (respondedUserIds.length > 0) {
        if (document.getElementById("no-answer-text")) {
            document.getElementById("no-answer-text").style.display = "none";
        }
        //Gets users' details (name, pic, phone number, etc.) against their ids
        KASClient.App.getUsersDetailsAsync(respondedUserIds, function(usersJson, error) {
            if (error != null) {
                showErrorMessage(strings["errorMessageSubtitle"]);
                return;
            }
            for (var j = 0; j < allAnswers.length; j++) {
                var userId = allAnswers[j].userId;
                allAnswers[j].pictureInitials = usersJson[userId].pictureInitials;
                allAnswers[j].pictureUrl = usersJson[userId].pictureUrl;
                allAnswers[j].name = usersJson[userId].name;
                allAnswers[j].response = allAnswers[j].userResponse[0];
                var responseTime = new Date(parseInt(allAnswers[j].userResponse[1]));
                allAnswers[j].time = responseTime;
            }
            // sorting based on ascending order of time
            allAnswers = allAnswers.sort(function(a, b) {
                return a.time - b.time;
            });
            createAnswerList(allAnswers);
        });
    }
}

function readProperties(form) {
    var properties = [];
    var prop = form.properties;
    for (var i = 0; i < prop.length; i++) {
        properties[prop[i].name] = prop[i].value;
    }
    return properties;
}

function createAnswerList(allAnswers) {
    document.getElementById("answers").innerHTML = "";
    for (var j = 0; j < allAnswers.length; j++) {
        var answerList = document.createElement("div");
        answerList.className = "answer-list";
        answerList.appendChild(createAnswerDiv(allAnswers[j]));
        var hr = document.createElement('hr');
        hr.className = "border";
        answerList.appendChild(hr);
        document.getElementById("answers").appendChild(answerList);
    }
}

function createAnswerDiv(answer) {
    var answerDiv = document.createElement("div");
    answerDiv.className = "answer";
    var responderImg = document.createElement("div");
    responderImg.className = "user-img";
    createProfilePic(answer['pictureUrl'], answer['pictureInitials'], responderImg);
    answerDiv.appendChild(responderImg);
    var response = document.createElement("div");
    response.className = "response";
    var responderName = document.createElement("div");
    responderName.innerText = answer['name'];
    responderName.className = "responder-name";

    var time = document.createElement("div");
    var formattedResonseTime = answer['time'].toLocaleTimeString([] /* it takes default locale of device */ , { hour: '2-digit', minute: '2-digit' }) + ', ' + answer['time'].toLocaleDateString([], { day: "numeric", month: "short" });
    time.innerText = formattedResonseTime;
    time.className = "question-time";
    responderName.appendChild(time);
    response.appendChild(responderName);

    var p = document.createElement("p");
    p.innerText = answer['response'];
    response.appendChild(p);
    answerDiv.appendChild(response);
    return answerDiv;

}

function loadQuestionData() {
    KASClient.Form.getFormAsync(function(form, error) {
        if (error != null) {
            showErrorMessage(strings["errorMessageSubtitle"]);
            return;
        }
        var properties = readProperties(form);
        var userId = properties["askedByUserId"];
        //Gets users' details (name, pic, phone number, etc.) against their ids
        KASClient.App.getUsersDetailsAsync([userId], function(users, error) {
            if (error != null) {
                showErrorMessage(strings["errorMessageSubtitle"]);
                return;
            }
            var askedByUser = users[userId];
            var askedByImg = document.getElementById("askedBy-img");
            createProfilePic(askedByUser.pictureUrl, askedByUser.pictureInitials, askedByImg);
            document.getElementById('askedBy-details').innerText = askedByUser.originalName;
            var questionTime = document.createElement('div');
            questionTime.innerText = properties["time"];
            questionTime.className = "question-time";
            document.getElementById('askedBy-details').appendChild(questionTime);
            document.getElementById('question').innerText = properties["question"];
        });
        if (properties["coverImage"])
            showSelectedImage(properties["coverImage"]);
    });
}

// Create the profile image of the user
function createProfilePic(pictureUrl, pictureInitials, imgDiv) {
    if (pictureUrl == "") {
        var userProfile = document.createElement("div");
        userProfile.className = "user-profile-pic";
        userProfile.innerText = pictureInitials;
        imgDiv.appendChild(userProfile);
    } else {
        var profilePic = document.createElement('img');
        profilePic.className = "profile-pic";
        profilePic.src = pictureUrl;
        imgDiv.appendChild(profilePic);
    }
}

function showSelectedImage(attachment) {
    var descriptionImage;
    var horizontalAttachmentDiv = document.getElementById("img-section");

    descriptionImage = document.createElement("img");
    descriptionImage.className = "section-selected-img";
    descriptionImage.src = attachment;

    var imageDiv = document.createElement("div");
    imageDiv.className = "show-img-div";
    imageDiv.appendChild(descriptionImage);
    imageDiv.addEventListener('click', showImageImmersiveView);
    horizontalAttachmentDiv.appendChild(imageDiv);
}

function showImageImmersiveView(event) {
    KASClient.App.showImageImmersiveView([properties["coverImage"]], 0);
}
//submit the answer
function submitResponse() {
    var questionToAnswerMap = {};
    var answer = document.getElementById("input-answer").innerText;
    if (answer != '') {
        questionToAnswerMap[0] = answer;
        questionToAnswerMap[1] = (new Date()).getTime();
        //To get latest form
        KASClient.Form.getFormAsync(function(form, error) {
            if (error != null) {
                showErrorMessage(strings["errorMessageSubtitle"]);
                return;
            }
            var properties = readProperties(form);
            var formPropertyUpdates = [];
            var lastResponder = strings["recentAnswerFrom"] + currentUserInfo.originalName;
            var lastResponderProperty = createProperty("lastResponder", KASClient.KASFormPropertyType.Text);
            var lastResponderPropertyUpdate = KASClient.KASFormPropertyUpdateFactory.updateValueInProperty(lastResponder, lastResponderProperty);
            formPropertyUpdates.push(lastResponderPropertyUpdate);

            if (properties["recentAnswer"] == null) {
                var recentAnswerProperty = createPropertyWithValue("recentAnswer", KASClient.KASFormPropertyType.Text, questionToAnswerMap[0]);
                var recentAnswerPropertyUpdate = KASClient.KASFormPropertyUpdateFactory.addProperty(recentAnswerProperty)
                formPropertyUpdates.push(recentAnswerPropertyUpdate);
            } else {
                var recentAnswerProperty = createProperty("recentAnswer", KASClient.KASFormPropertyType.Text);
                var recentAnswerPropertyUpdate = KASClient.KASFormPropertyUpdateFactory.updateValueInProperty(questionToAnswerMap[0], recentAnswerProperty)
                formPropertyUpdates.push(recentAnswerPropertyUpdate);
            }
            sendNotification(properties["askedByUserId"], "answerPosted");
            KASClient.Form.updateFormPropertiesAsync(formPropertyUpdates /* data for chat canvas view */ );
            KASClient.Form.sumbitFormResponse(questionToAnswerMap /* Responses to server*/ );
        });
    }

}
// send notification to user asking the question
function sendNotification(userId, action) {
    // Create a property update info
    var customNotification = new KASClient.CustomNotificationMessage();
    customNotification.priority = KASClient.NotificationPriority.Medium;
    var object = {};
    object["nT"] = action; //Name of the notificationTemplate from notificationModel file.
    customNotification.notificationBag = object; // Set of properties that can be read in the notificationModel
    customNotification.userIds = [userId]; // GUID of the user not the phone #.
    KASClient.Form.sendNotificationToUsers(customNotification);
}

//Create property with value
function createPropertyWithValue(name, type, value) {
    var property = new KASClient.KASFormProperty();
    property.name = name;
    property.type = type;
    property.value = value;
    return property;
}
//create property
function createProperty(name, type) {
    var property = new KASClient.KASFormProperty();
    property.name = name;
    property.type = type;
    return property;
}

function reload() {
    fetchAndShowAllResponses();
}

function showErrorMessage(errorMessage) {
    var okButton = document.getElementById('ok-button-text');
    okButton.addEventListener('click', KASClient.App.dismissCurrentScreen);
    okButton.textContent = strings['Ok'];
    document.getElementById("error-message-title").textContent = strings["errorMessageTitle"];
    document.getElementById("error-message-subtitle").textContent = errorMessage;
    document.getElementById("error-message-outer-div").style.display = "flex";
}

function checkOnline() {
    if (!navigator.onLine) {
        showErrorMessage(strings["NoNetwork"]);
    }
}