//Globals
var form = null; //type: KASForm
var strings = null;
var currentThemeIndex = 0;
var customImagePath = "";
var themes = ['0.png', '1.png', '2.png', '3.png', '4.png'];

/*
setNextThemeAsBackground(): Calculate the next theme and set it as background
*/
function setNextThemeAsBackground() {
    currentThemeIndex = (currentThemeIndex + 1) % (themes.length);
    setBackground(currentThemeIndex);
}

/*
setCurrentThemeAsBackground(): Set the current theme as background
*/
function setCurrentThemeAsBackground() {
    setBackground(currentThemeIndex);
}

/*
setBackground(themeIndexToBeSet): themeIndexToBeSet sets the background to the themeIndexToBeSet-th image.
*/
function setBackground(themeIndexToBeSet) {
    var themeChangerButton = document.getElementById('themechanger-button');
    var quoteDiv = document.getElementById('quote-div');

    quoteDiv.style = 'background: url(\'' + themes[themeIndexToBeSet] + '\') no-repeat;';
    themeChangerButton.style = 'background: url(\'' + themes[(themeIndexToBeSet + 1) % (themes.length)] + '\') no-repeat;'; //preview the next available theme/background

    //To handle the case when the theme is changed with an image already uploaded (hide the close button and remove the image URL)
    setRemoveImageButtonVisibility(false);
    customImagePath = "";
    changeSubmitButtonState();
}

/*
changeSubmitButtonState(): change the state of submit button based on data in the main quotes section or image upload
*/
function changeSubmitButtonState() {
    var submitButton = document.getElementById("submit");
    if ((document.getElementById('main-quote-text').value != "") || (customImagePath != "")) { // Enable Send Button
        submitButton.style.pointerEvents = 'auto';
        submitButton.style.color = '#2196F3';
    } else { // Disable Send Button
        submitButton.style.pointerEvents = 'none';
        submitButton.style.color = '#C0C0C0';
    }
}

/*
onPageLoad(): loads the response view (header,body) of the card
*/
function onPageLoad() {
    //Enable Hardware Back button
    KASClient.App.registerHardwareBackPressCallback(function() {
        KASClient.App.dismissCurrentScreen();
    });

    KASClient.App.getLocalizedStringsAsync(function(localizedStrings, error) {
        if (error != null) {
            return;
        }
        strings = localizedStrings;
        // Get the default form
        KASClient.Form.getFormAsync(function(formDetails, error) {
            if (error != null) {
                return;
            }
            form = formDetails;
            setInitialText();
            initializeEventListeners();
        });
    });
}

/*
submitData(): Submit data to Kaizala
*/
function submitData() {
    //Hiding Customization Buttons when before taking snap of ParentContainer using html2canvas
    document.getElementById("remove-image-button").style.display = "none";
    document.getElementById("customization-elements").style.display = "none";

    html2canvas(document.getElementById("parent-container")).then(canvas => {
        form.properties = [];
        var finalImage = canvas.toDataURL();
        var properties = form.properties;
        var finalImageProperty = new KASClient.KASFormProperty();
        finalImageProperty.name = "FinalImage";
        finalImageProperty.type = KASClient.KASFormPropertyType.Attachment;
        finalImageProperty.value = finalImage;
        properties[properties.length] = finalImageProperty;

        var tellUsMoreProperty = new KASClient.KASFormProperty();
        tellUsMoreProperty.name = "TellUsMoreText";
        tellUsMoreProperty.type = KASClient.KASFormPropertyType.Text;
        tellUsMoreProperty.value = document.getElementById("more-div-text").innerText;
        properties[properties.length] = tellUsMoreProperty;

        /*
        Since everyone else in the flat group should be able to view the quote created by one user, we are submitting properties in the form of a request
        */
        KASClient.Form.submitFormRequest(form);
    });
}

/*
uploadCustomImage(): Upload an image from your gallery and set the background. Also show the Remove Image button after setting the background.
*/
function uploadCustomImage() {
    KASClient.App.showImagePickerAsync(function(selectedImagePath, error) {
        if (error != null) {
            return;
        }

        if (selectedImagePath) {
            setRemoveImageButtonVisibility(true);
            document.getElementById("quote-div").style = 'background: url(\'' + selectedImagePath + '\') center; background-size: cover;';
            customImagePath = selectedImagePath;
            changeSubmitButtonState();
        }
    });
}

/*
removeUploadedImage():Remove the cutom background image and restore the current theme. Also hide the Remove Image button as no custom image is available.
*/
function removeUploadedImage() {
    customImagePath = "";
    setCurrentThemeAsBackground();
    changeSubmitButtonState();
}

/*
setInitialText(): Initialized placeholders and button texts
*/
function setInitialText() {
    document.getElementById("header-label").innerText = strings["displayName"];
    document.getElementById("main-quote-text").placeholder = strings["mainQuotePlaceholder"];
    document.getElementById("quote-byline-text").placeholder = strings["quoteByLinePlaceholder"];
    document.getElementById('more-div-text').setAttribute("placeholder", strings["tellUsMorePlaceholder"]);
    document.getElementById("submit").innerText = strings["submitData"];
}

/*
setRemoveImageButtonVisibility(): Show or hide "RemoveImageButton" based on show = true/false respectively
*/
function setRemoveImageButtonVisibility(show) {
    var removeImageButton = document.getElementById("remove-image-button");
    if (show) {
        removeImageButton.style.display = "block";
    } else {
        removeImageButton.style.display = "none";
    }
}

/*
initializeEventListeners(): Initialize the event listeners in the page
*/
function initializeEventListeners() {
    var backButton = document.getElementById("back-button");
    var removeImageButton = document.getElementById("remove-image-button");
    var mainQuoteText = document.getElementById("main-quote-text");
    var themeChangerButton = document.getElementById("themechanger-button");
    var imagePickerButton = document.getElementById("imagepicker-button");
    var submitButton = document.getElementById("submit");

    backButton.addEventListener("click", KASClient.App.dismissCurrentScreen);
    removeImageButton.addEventListener("click", removeUploadedImage);

    mainQuoteText.addEventListener("keyup", changeSubmitButtonState);
    mainQuoteText.addEventListener("change", changeSubmitButtonState);

    themeChangerButton.addEventListener("click", setNextThemeAsBackground);
    imagePickerButton.addEventListener("click", uploadCustomImage);
    submitButton.addEventListener("click", submitData);
}