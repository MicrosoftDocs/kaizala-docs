//Globals
var strings = null;
/*
onPageLoad(): loads the summary view (header,body) of the card
*/
function onPageLoad() {
    KASClient.App.registerHardwareBackPressCallback(function() {
        KASClient.App.dismissCurrentScreen();
    });

    KASClient.App.getLocalizedStringsAsync(function(localizedStrings, error) {
        if (error != null) {
            return;
        }
        strings = localizedStrings;
        KASClient.Form.getFormAsync(function(form, error) {
            if (error != null) {
                return;
            }
            var formProperties = createFormPropertiesMap(form);
            document.getElementById("summary-header-label").innerText = strings["displayName"];
            document.getElementById("back-button").addEventListener("click", KASClient.App.dismissCurrentScreen);
            showImmersiveView(formProperties);
        });
    });
}

/*
createFormPropertiesMap(form): get the properties of the form
*/
function createFormPropertiesMap(form) {
    var formPropsMap = {};
    for (var i = 0; i < form.properties.length; i++) {
        var property = form.properties[i];
        formPropsMap[property.name] = property.value;
    }
    return formPropsMap;
}

/*
showImmersiveView(formProperties): Show the immersive view of the card
*/
function showImmersiveView(formProperties) {
    document.getElementById("quote-img").src = formProperties["FinalImage"];
    document.getElementById('more-txt').innerText = formProperties["TellUsMoreText"];
}